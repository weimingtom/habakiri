// document id
var doc_id = "tjs2doc";
