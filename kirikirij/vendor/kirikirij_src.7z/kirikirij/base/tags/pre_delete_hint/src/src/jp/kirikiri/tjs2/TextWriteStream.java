// 一部未実装。本来は吉里吉里側で実装
package jp.kirikiri.tjs2;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class TextWriteStream {

	private OutputStream mStream;

	public TextWriteStream( OutputStream stream ) {
		mStream = stream;
	}
	public TextWriteStream(String name, String mode) throws TJSException {
		try {
			mStream = new FileOutputStream(name);
			// TODO 詳しく書く
		} catch (FileNotFoundException e) {
			throw new TJSException( Error.WriteError + e.toString() );
		}
	}
	public void write( final String val ) {
		try {
			mStream.write( val.getBytes() );
		} catch (IOException e) {
		}
	}
	public void destruct() {
		try {
			mStream.close();
		} catch (IOException e) {
		}
	}
}
