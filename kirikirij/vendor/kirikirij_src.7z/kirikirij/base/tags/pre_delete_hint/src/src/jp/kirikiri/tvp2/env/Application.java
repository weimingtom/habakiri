/**
 * 環境依存の処理を入れる
 *
 */
package jp.kirikiri.tvp2.env;

import javax.swing.JOptionPane;

public class Application {
	public static int
		MB_OK = 1,
		MB_ICONSTOP = 2;

	public static void messageBox( final String caption, final String title, final int flags ) {
		//ERROR_MESSAGE、INFORMATION_MESSAGE、WARNING_MESSAGE、QUESTION_MESSAGE、または PLAIN_MESSAGE
		int messageType = JOptionPane.ERROR_MESSAGE;
		if( (flags & MB_OK) != 0 ) {
		}
		if( (flags & MB_ICONSTOP) != 0 ) {
		}
		JOptionPane.showMessageDialog( null, caption, title, messageType );
	}
}
