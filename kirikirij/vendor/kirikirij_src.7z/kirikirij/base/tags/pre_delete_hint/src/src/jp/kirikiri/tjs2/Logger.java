package jp.kirikiri.tjs2;

public class Logger {
	public static void log( final String tag, final String message ) {
		System.out.println(tag + " : " + message );
		// Log.v( tag, message );	// for android
	}
	public static void log( final String message ) {
		System.out.println(message );
		// Log.v( "Logger", message );	// for android
	}
}

