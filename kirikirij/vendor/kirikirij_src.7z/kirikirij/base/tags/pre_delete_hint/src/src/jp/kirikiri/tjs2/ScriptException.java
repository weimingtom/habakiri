package jp.kirikiri.tjs2;

public class ScriptException extends Exception {

	/**
	 *
	 */
	private static final long serialVersionUID = 61567993834917176L;
	public ScriptException() {}
	public ScriptException( String msg ) {
		super( msg );
	}
}

