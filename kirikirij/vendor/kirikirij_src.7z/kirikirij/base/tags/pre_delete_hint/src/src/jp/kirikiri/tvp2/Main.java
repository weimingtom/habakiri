package jp.kirikiri.tvp2;

import jp.kirikiri.tjs2.TJSException;
import jp.kirikiri.tjs2.VariantException;
import jp.kirikiri.tvp2.base.ScriptsClass;

class Main {

    public static void main(String[] args) {
/*
    	TJS tjs = new TJS();
    	String script = "c = (a=1, b=2)";
    	PreprocessorExpressionParser parser = new PreprocessorExpressionParser( tjs, script );
    	int result = -1;
		try {
			result = parser.parse();
		} catch (CompileException e) {
			e.printStackTrace();
		}
    	System.out.println("result:" + result);
*/

		try {
			ScriptsClass.initScriptEnging();
			System.gc(); // TODO
			ScriptsClass.executeStartupScript();
		} catch (VariantException e) {
			e.printStackTrace();
		} catch (TJSException e) {
			e.printStackTrace();
		}
    }
}
