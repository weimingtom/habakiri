/**
 * スタティックメソッドとして TJS に登録するためのアノテーション
 * TODO Android でも使えると思うけど、無理なら他の方法で実装する
 */
package jp.kirikiri.tjs2;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 *
 *
 */
@Retention(RetentionPolicy.RUNTIME)
public @interface TJSStatic {

}
