package jp.kirikiri.tjs2;


public class VariantClosure /*implements Cloneable*/ {

	public Dispatch2	mObject;
	public Dispatch2	mObjThis;

	public VariantClosure( Dispatch2 obj ) {
		this( obj, null );
	}
	public VariantClosure( Dispatch2 obj, Dispatch2 objthis ) {
		mObject = obj;
		mObjThis = objthis;
	}
	public void set( Dispatch2 obj ) {
		set( obj, null );
	}
	public void set( Dispatch2 obj, Dispatch2 objthis ) {
		mObject = obj;
		mObjThis = objthis;
	}
	public Dispatch2 selectObject() {
		if( mObjThis != null ) return mObjThis;
		else return mObject;
	}
	public boolean equals( Object o ) {
		if( o instanceof VariantClosure ) {
			VariantClosure vc = (VariantClosure)o;
			return mObject == vc.mObject && mObjThis == vc.mObjThis;
		} else {
			return false ;
		}
	}
	/*
	public Object clone() {
		VariantClosure r;
		try {
			r = (VariantClosure)super.clone();
		} catch (CloneNotSupportedException e) {
			return null;
		}
		Object o = null;
		if( mObject != null ) o = mObject.clone();
		Object t = null;
		if( mObjThis != null ) t = mObjThis.clone();
		r.set( o, t );
		return r;
	}
	*/
	public int funcCall( int flag, final String memberName, IntWrapper hint, Variant result, Variant[] param, Dispatch2 objThis ) throws TJSException, VariantException {
		if( mObject == null ) throw new TJSException(Error.NullAccess);
		return mObject.funcCall( flag, memberName, hint, result, param,
				mObjThis != null ? mObjThis : (objThis != null ? objThis : mObject) );
	}

	public int funcCallByNum( int flag, int num, Variant result, Variant[] param, Dispatch2 objThis ) throws TJSException, VariantException {
		if( mObject == null ) throw new TJSException(Error.NullAccess);
		return mObject.funcCallByNum(flag, num, result, param,
				mObjThis != null ? mObjThis : (objThis != null ? objThis : mObject) );
	}

	public int propGet( int flag, final String mumberName, IntWrapper hint, Variant result, Dispatch2 objThis ) throws TJSException, VariantException {
		if( mObject == null ) throw new TJSException(Error.NullAccess);
		return mObject.propGet(flag, mumberName, hint, result,
				mObjThis != null ? mObjThis : (objThis != null ? objThis : mObject) );
	}

	public int propGetByNum( int flag, int num, Variant result, Dispatch2 objThis ) throws TJSException, VariantException {
		if( mObject == null ) throw new TJSException(Error.NullAccess);
		return mObject.propGetByNum(flag, num, result,
				mObjThis != null ? mObjThis : (objThis != null ? objThis : mObject) );
	}

	public int propSet( int flag, String mumberName, IntWrapper hint, final Variant param, Dispatch2 objThis ) throws TJSException, VariantException {
		if( mObject == null ) throw new TJSException(Error.NullAccess);
		return mObject.propSet(flag, mumberName, hint, param,
				mObjThis != null ? mObjThis : (objThis != null ? objThis : mObject) );
	}

	public int propSetByNum( int flag, int num, final Variant param, Dispatch2 objThis ) throws TJSException, VariantException {
		if( mObject == null ) throw new TJSException(Error.NullAccess);
		return mObject.propSetByNum(flag, num, param,
				mObjThis != null ? mObjThis : (objThis != null ? objThis : mObject) );
	}

	public int getCount( IntWrapper result, final String memberName, IntWrapper hint, Dispatch2 objThis ) throws TJSException, VariantException {
		if( mObject == null ) throw new TJSException(Error.NullAccess);
		return mObject.getCount(result, memberName, hint,
				mObjThis != null ? mObjThis : (objThis != null ? objThis : mObject) );
	}

	public int getCountByNum( IntWrapper result, int num, Dispatch2 objThis ) throws TJSException, VariantException {
		if( mObject == null ) throw new TJSException(Error.NullAccess);
		return mObject.getCountByNum(result, num,
				mObjThis != null ? mObjThis : (objThis != null ? objThis : mObject) );
	}

	public int propSetByVS( int flag, String memberName, final Variant param, Dispatch2 objThis ) throws TJSException, VariantException {
		if( mObject == null ) throw new TJSException(Error.NullAccess);
		return mObject.propSetByVS(flag, memberName, param,
				mObjThis != null ? mObjThis : (objThis != null ? objThis : mObject) );
	}

	public int enumMembers( int flag, VariantClosure callback, Dispatch2 objThis ) throws TJSException, VariantException {
		if( mObject == null ) throw new TJSException(Error.NullAccess);
		return mObject.enumMembers(flag, callback,
				mObjThis != null ? mObjThis : (objThis != null ? objThis : mObject) );
	}

	public int deleteMember( int flag, String memberName, IntWrapper hint, Dispatch2 objThis ) throws TJSException, VariantException {
		if( mObject == null ) throw new TJSException(Error.NullAccess);
		return mObject.deleteMember(flag, memberName, hint,
				mObjThis != null ? mObjThis : (objThis != null ? objThis : mObject) );
	}

	public int deleteMemberByNum( int flag, int num, Dispatch2 objThis ) throws TJSException, VariantException {
		if( mObject == null ) throw new TJSException(Error.NullAccess);
		return mObject.deleteMemberByNum(flag, num,
				mObjThis != null ? mObjThis : (objThis != null ? objThis : mObject) );
	}

	public int invalidate( int flag, String memberName, IntWrapper hint, Dispatch2 objThis ) throws TJSException, VariantException {
		if( mObject == null ) throw new TJSException(Error.NullAccess);
		return mObject.invalidate(flag, memberName, hint,
				mObjThis != null ? mObjThis : (objThis != null ? objThis : mObject) );
	}

	public int invalidateByNum( int flag, int num, Dispatch2 objThis ) throws TJSException, VariantException {
		if( mObject == null ) throw new TJSException(Error.NullAccess);
		return mObject.invalidateByNum(flag, num,
				mObjThis != null ? mObjThis : (objThis != null ? objThis : mObject) );
	}

	public int isValid( int flag, String memberName, IntWrapper hint, Dispatch2 objThis ) throws TJSException, VariantException {
		if( mObject == null ) throw new TJSException(Error.NullAccess);
		return mObject.isValid(flag, memberName, hint,
				mObjThis != null ? mObjThis : (objThis != null ? objThis : mObject) );
	}

	public int isValidByNum( int flag, int num, Dispatch2 objThis ) throws TJSException, VariantException {
		if( mObject == null ) throw new TJSException(Error.NullAccess);
		return mObject.isValidByNum(flag, num,
				mObjThis != null ? mObjThis : (objThis != null ? objThis : mObject) );
	}

	public int createNew( int flag, String memberName, IntWrapper hint, Holder<Dispatch2> result, Variant[] param, Dispatch2 objThis ) throws TJSException, VariantException {
		if( mObject == null ) throw new TJSException(Error.NullAccess);
		return mObject.createNew(flag, memberName, hint, result, param,
				mObjThis != null ? mObjThis : (objThis != null ? objThis : mObject) );
	}

	public int createNewByNum( int flag, int num, Holder<Dispatch2> result, Variant[] param, Dispatch2 objThis ) throws TJSException, VariantException {
		if( mObject == null ) throw new TJSException(Error.NullAccess);
		return mObject.createNewByNum(flag, num, result, param,
				mObjThis != null ? mObjThis : (objThis != null ? objThis : mObject) );
	}

	public int isInstanceOf( int flag, String memberName, IntWrapper hint, String className, Dispatch2 objThis ) throws TJSException, VariantException {
		if( mObject == null ) throw new TJSException(Error.NullAccess);
		return mObject.isInstanceOf(flag, memberName, hint, className,
				mObjThis != null ? mObjThis : (objThis != null ? objThis : mObject) );
	}

	// オリジナルはバグ？ 関数名が一致していない
	//tjs_error IsInstanceOf(tjs_uint32 flag, tjs_int num, tjs_char *classname, iTJSDispatch2 *objthis) const {
	public int isInstanceOfByNum( int flag, int num, String className, Dispatch2 objThis ) throws TJSException, VariantException {
		if( mObject == null ) throw new TJSException(Error.NullAccess);
		return mObject.isInstanceOfByNum(flag, num, className,
				mObjThis != null ? mObjThis : (objThis != null ? objThis : mObject) );
	}

	public int operation( int flag, String memberName, IntWrapper hint, Variant result, final Variant param, Dispatch2 objThis ) throws TJSException, VariantException {
		if( mObject == null ) throw new TJSException(Error.NullAccess);
		return mObject.operation(flag, memberName, hint, result, param,
				mObjThis != null ? mObjThis : (objThis != null ? objThis : mObject) );
	}

	public int operationByNum( int flag, int num, Variant result, final Variant param, Dispatch2 objThis ) throws TJSException, VariantException {
		if( mObject == null ) throw new TJSException(Error.NullAccess);
		return mObject.operationByNum(flag, num, result, param,
				mObjThis != null ? mObjThis : (objThis != null ? objThis : mObject) );
	}
}
