package jp.kirikiri.tjs2;

public class CompileException extends Exception {

	/**
	 *
	 */
	private static final long serialVersionUID = 560827963479780060L;
	public CompileException() {}
	public CompileException( String msg ) {
		super( msg );
	}
}

