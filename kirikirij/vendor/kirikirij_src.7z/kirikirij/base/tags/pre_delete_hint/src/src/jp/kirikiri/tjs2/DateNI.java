package jp.kirikiri.tjs2;

import java.util.Calendar;

public class DateNI extends NativeInstanceObject {
	public Calendar mDateTime;
}
