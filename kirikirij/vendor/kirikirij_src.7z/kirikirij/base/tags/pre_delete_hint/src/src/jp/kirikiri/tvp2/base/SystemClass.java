package jp.kirikiri.tvp2.base;

import jp.kirikiri.tjs2.NativeClass;
import jp.kirikiri.tjs2.NativeInstance;
import jp.kirikiri.tjs2.TJS;
import jp.kirikiri.tjs2.TJSException;
import jp.kirikiri.tjs2.Variant;
import jp.kirikiri.tjs2.VariantException;

public class SystemClass extends NativeClass {
	private static final int MEMBERENSURE = 0x00000200; // create a member if not exists
	/*
	static private final int
		E_BADPARAMCOUNT	= -1004,
		S_OK			= 0;
	*/

	static public int mClassID;

	protected NativeInstance createNativeInstance() {
		// this class cannot create an instance
		// TODO 後で実装する
		// TVPThrowExceptionMessage(TVPCannotCreateInstance);
		return null;
	}

	public SystemClass() throws VariantException, TJSException {
		super("System");
		final String __classname = "System";
		final int NCM_CLASSID = TJS.registerNativeClass(__classname);
		setClassID( NCM_CLASSID );
		mClassID = NCM_CLASSID;

		Class<? extends SystemClass> c = getClass();
		registerMethods( c, __classname );


		// register default "exceptionHandler" member
		Variant val = new Variant( null, null );
		propSet( MEMBERENSURE, "exceptionHandler", null, val, this);

		// and onActivate, onDeactivate
		propSet( MEMBERENSURE, "onActivate", null, val, this);
		propSet( MEMBERENSURE, "onDeactivate", null, val, this);
	}
}
