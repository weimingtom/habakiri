package jp.kirikiri.tjs2;

public class ExceptionClass extends NativeClass {

	static private final int S_OK = 0;
	static private final int MEMBERENSURE = 0x00000200; // create a member if not exists
	static public int mClassID = -1;

	public ExceptionClass() throws VariantException, TJSException {
		super("Exception");
		final String __classname = "Exception";
		final int NCM_CLASSID = TJS.registerNativeClass(__classname);
		setClassID( NCM_CLASSID );
		mClassID = NCM_CLASSID;

		Class<? extends ExceptionClass> c = getClass();
		registerMethods( c, __classname );
	}
	public static int constructor( Variant result, Variant[] param, Dispatch2 objthis ) throws VariantException, TJSException {

		Variant val = new Variant("");
		if( (param.length > 0) ? param[0].isVoid() != true : false ) {
			val.copyRef( param[0] );
		}

		final String message_name = "message";
		IntWrapper hint = new IntWrapper( message_name.hashCode() );
		objthis.propSet( MEMBERENSURE, message_name, hint, val, objthis );

		if( (param.length > 1) ? param[1].isVoid() != true : false ) {
			val.copyRef( param[1] );
		} else {
			val.set( "" );
		}

		final String trace_name = "trace";
		hint = new IntWrapper( trace_name.hashCode() );
		objthis.propSet( MEMBERENSURE, trace_name, hint, val, objthis);
		return S_OK;
	}
	public static int finalize( Variant result, Variant[] param, Dispatch2 objthis ) {
		return S_OK;
	}
}
