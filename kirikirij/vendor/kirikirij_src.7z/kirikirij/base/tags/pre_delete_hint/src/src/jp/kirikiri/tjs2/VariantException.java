package jp.kirikiri.tjs2;

public class VariantException extends TJSException {

	/**
	 *
	 */
	private static final long serialVersionUID = -3605064460238917638L;
	public VariantException() {}
	public VariantException( String msg ) {
		super( msg );
	}
}

