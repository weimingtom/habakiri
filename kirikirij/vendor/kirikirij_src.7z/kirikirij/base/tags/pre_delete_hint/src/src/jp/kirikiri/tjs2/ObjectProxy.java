package jp.kirikiri.tjs2;

public class ObjectProxy implements Dispatch2 {
/*
	a class that do:
	1. first access to the Dispatch1
	2. if failed, then access to the Dispatch2
*/
	private static final int
		E_MEMBERNOTFOUND	= -1001,
		E_NOTIMPL			= -1002;


	public ObjectProxy() {}

	private Dispatch2 mDispatch1;
	private Dispatch2 mDispatch2;

	public void setObjects( Dispatch2 dsp1, Dispatch2 dsp2 )
	{
		mDispatch1 = dsp1;
		mDispatch2 = dsp2;
	}

	@Override
	public int funcCall(int flag, String membername, IntWrapper hint, Variant result, Variant[] param, Dispatch2 objthis) throws VariantException, TJSException {
		Dispatch2 OBJ1 = ((objthis != null) ? (objthis) : (mDispatch1));
		int hr = mDispatch1.funcCall(flag, membername, hint, result, param, OBJ1);
		if( hr == E_MEMBERNOTFOUND && mDispatch1 != mDispatch2 ) {
			Dispatch2 OBJ2 = ((objthis != null) ? (objthis) : (mDispatch2));
			return mDispatch2.funcCall(flag, membername, hint, result, param, OBJ2);
		}
		return hr;
	}

	@Override
	public int funcCallByNum(int flag, int num, Variant result, Variant[] param, Dispatch2 objthis) throws VariantException, TJSException {
		Dispatch2 OBJ1 = ((objthis != null) ? (objthis) : (mDispatch1));
		int hr = mDispatch1.funcCallByNum(flag, num, result, param, OBJ1);
		if( hr == E_MEMBERNOTFOUND && mDispatch1 != mDispatch2 ) {
			Dispatch2 OBJ2 = ((objthis != null) ? (objthis) : (mDispatch2));
			return mDispatch2.funcCallByNum(flag, num, result, param, OBJ2);
		}
		return hr;
	}

	@Override
	public int propGet(int flag, String membername, IntWrapper hint, Variant result, Dispatch2 objthis) throws VariantException, TJSException {
		Dispatch2 OBJ1 = ((objthis != null) ? (objthis) : (mDispatch1));
		int hr =mDispatch1.propGet(flag, membername, hint, result, OBJ1);
		if(hr == E_MEMBERNOTFOUND && mDispatch1 != mDispatch2) {
			Dispatch2 OBJ2 = ((objthis != null) ? (objthis) : (mDispatch2));
			return mDispatch2.propGet(flag, membername, hint, result, OBJ2);
		}
		return hr;
	}

	@Override
	public int propGetByNum(int flag, int num, Variant result, Dispatch2 objthis) throws VariantException, TJSException {
		Dispatch2 OBJ1 = ((objthis != null) ? (objthis) : (mDispatch1));
		int hr = mDispatch1.propGetByNum(flag, num, result, OBJ1);
		if(hr == E_MEMBERNOTFOUND && mDispatch1 != mDispatch2) {
			Dispatch2 OBJ2 = ((objthis != null) ? (objthis) : (mDispatch2));
			return mDispatch2.propGetByNum(flag, num, result, OBJ2);
		}
		return hr;
	}

	@Override
	public int propSet(int flag, String membername, IntWrapper hint, Variant param, Dispatch2 objthis) throws VariantException, TJSException {
		Dispatch2 OBJ1 = ((objthis != null) ? (objthis) : (mDispatch1));
		int hr = mDispatch1.propSet(flag, membername, hint, param, OBJ1);
		if(hr == E_MEMBERNOTFOUND && mDispatch1 != mDispatch2) {
			Dispatch2 OBJ2 = ((objthis != null) ? (objthis) : (mDispatch2));
			return mDispatch2.propSet(flag, membername, hint, param, OBJ2);
		}
		return hr;
	}

	@Override
	public int propSetByNum(int flag, int num, Variant param, Dispatch2 objthis) throws VariantException, TJSException {
		Dispatch2 OBJ1 = ((objthis != null) ? (objthis) : (mDispatch1));
		int hr = mDispatch1.propSetByNum(flag, num, param, OBJ1);
		if(hr == E_MEMBERNOTFOUND && mDispatch1 != mDispatch2) {
			Dispatch2 OBJ2 = ((objthis != null) ? (objthis) : (mDispatch2));
			return mDispatch2.propSetByNum(flag, num, param, OBJ2);
		}
		return hr;
	}

	@Override
	public int getCount(IntWrapper result, String membername, IntWrapper hint, Dispatch2 objthis) throws VariantException, TJSException {
		Dispatch2 OBJ1 = ((objthis != null) ? (objthis) : (mDispatch1));
		int hr = mDispatch1.getCount(result, membername, hint, OBJ1);
		if(hr == E_MEMBERNOTFOUND && mDispatch1 != mDispatch2) {
			Dispatch2 OBJ2 = ((objthis != null) ? (objthis) : (mDispatch2));
			return mDispatch2.getCount(result, membername, hint, OBJ2);
		}
		return hr;
	}

	@Override
	public int getCountByNum(IntWrapper result, int num, Dispatch2 objthis) throws VariantException, TJSException {
		Dispatch2 OBJ1 = ((objthis != null) ? (objthis) : (mDispatch1));
		int hr = mDispatch1.getCountByNum(result, num, OBJ1);
		if(hr == E_MEMBERNOTFOUND && mDispatch1 != mDispatch2) {
			Dispatch2 OBJ2 = ((objthis != null) ? (objthis) : (mDispatch2));
			return mDispatch2.getCountByNum(result, num, OBJ2);
		}
		return hr;
	}

	@Override
	public int propSetByVS(int flag, String membername, Variant param, Dispatch2 objthis) throws VariantException, TJSException {
		Dispatch2 OBJ1 = ((objthis != null) ? (objthis) : (mDispatch1));
		int hr = mDispatch1.propSetByVS(flag, membername, param, OBJ1);
		if(hr == E_MEMBERNOTFOUND && mDispatch1 != mDispatch2) {
			Dispatch2 OBJ2 = ((objthis != null) ? (objthis) : (mDispatch2));
			return mDispatch2.propSetByVS(flag, membername, param, OBJ2);
		}
		return hr;
	}

	@Override
	public int enumMembers(int flag, VariantClosure callback, Dispatch2 objthis) throws VariantException, TJSException {
		return E_NOTIMPL;
	}

	@Override
	public int deleteMember(int flag, String membername, IntWrapper hint, Dispatch2 objthis) throws VariantException, TJSException {
		Dispatch2 OBJ1 = ((objthis != null) ? (objthis) : (mDispatch1));
		int hr = mDispatch1.deleteMember(flag, membername, hint, OBJ1);
		if(hr == E_MEMBERNOTFOUND && mDispatch1 != mDispatch2) {
			Dispatch2 OBJ2 = ((objthis != null) ? (objthis) : (mDispatch2));
			return mDispatch2.deleteMember(flag, membername, hint, OBJ2);
		}
		return hr;
	}

	@Override
	public int deleteMemberByNum(int flag, int num, Dispatch2 objthis) throws VariantException, TJSException {
		Dispatch2 OBJ1 = ((objthis != null) ? (objthis) : (mDispatch1));
		int hr = mDispatch1.deleteMemberByNum(flag, num, OBJ1);
		if(hr == E_MEMBERNOTFOUND && mDispatch1 != mDispatch2) {
			Dispatch2 OBJ2 = ((objthis != null) ? (objthis) : (mDispatch2));
			return mDispatch2.deleteMemberByNum(flag, num, OBJ2);
		}
		return hr;
	}

	@Override
	public int invalidate(int flag, String membername, IntWrapper hint, Dispatch2 objthis) throws VariantException, TJSException {
		Dispatch2 OBJ1 = ((objthis != null) ? (objthis) : (mDispatch1));
		int hr = mDispatch1.invalidate(flag, membername, hint, OBJ1);
		if(hr == E_MEMBERNOTFOUND && mDispatch1 != mDispatch2) {
			Dispatch2 OBJ2 = ((objthis != null) ? (objthis) : (mDispatch2));
			return mDispatch2.invalidate(flag, membername, hint, OBJ2);
		}
		return hr;
	}

	@Override
	public int invalidateByNum(int flag, int num, Dispatch2 objthis) throws VariantException, TJSException {
		Dispatch2 OBJ1 = ((objthis != null) ? (objthis) : (mDispatch1));
		int hr = mDispatch1.invalidateByNum(flag, num, OBJ1);
		if(hr == E_MEMBERNOTFOUND && mDispatch1 != mDispatch2) {
			Dispatch2 OBJ2 = ((objthis != null) ? (objthis) : (mDispatch2));
			return mDispatch2.invalidateByNum(flag, num, OBJ2);
		}
		return hr;
	}

	@Override
	public int isValid(int flag, String membername, IntWrapper hint, Dispatch2 objthis) throws VariantException, TJSException {
		Dispatch2 OBJ1 = ((objthis != null) ? (objthis) : (mDispatch1));
		int hr = mDispatch1.isValid(flag, membername, hint, OBJ1);
		if(hr == E_MEMBERNOTFOUND && mDispatch1 != mDispatch2) {
			Dispatch2 OBJ2 = ((objthis != null) ? (objthis) : (mDispatch2));
			return mDispatch2.isValid(flag, membername, hint, OBJ2);
		}
		return hr;
	}

	@Override
	public int isValidByNum(int flag, int num, Dispatch2 objthis) throws VariantException, TJSException {
		Dispatch2 OBJ1 = ((objthis != null) ? (objthis) : (mDispatch1));
		int hr = mDispatch1.isValidByNum(flag, num, OBJ1);
		if(hr == E_MEMBERNOTFOUND && mDispatch1 != mDispatch2) {
			Dispatch2 OBJ2 = ((objthis != null) ? (objthis) : (mDispatch2));
			return mDispatch2.isValidByNum(flag, num, OBJ2);
		}
		return hr;
	}

	@Override
	public int createNew(int flag, String membername, IntWrapper hint, Holder<Dispatch2> result, Variant[] param, Dispatch2 objthis) throws VariantException, TJSException {
		Dispatch2 OBJ1 = ((objthis != null) ? (objthis) : (mDispatch1));
		int hr = mDispatch1.createNew(flag, membername, hint, result, param, OBJ1);
		if(hr == E_MEMBERNOTFOUND && mDispatch1 != mDispatch2) {
			Dispatch2 OBJ2 = ((objthis != null) ? (objthis) : (mDispatch2));
			return mDispatch2.createNew(flag, membername, hint, result, param, OBJ2);
		}
		return hr;
	}

	@Override
	public int createNewByNum(int flag, int num, Holder<Dispatch2> result, Variant[] param, Dispatch2 objthis) throws VariantException, TJSException {
		Dispatch2 OBJ1 = ((objthis != null) ? (objthis) : (mDispatch1));
		int hr = mDispatch1.createNewByNum(flag, num, result, param, OBJ1);
		if(hr == E_MEMBERNOTFOUND && mDispatch1 != mDispatch2) {
			Dispatch2 OBJ2 = ((objthis != null) ? (objthis) : (mDispatch2));
			return mDispatch2.createNewByNum(flag, num, result, param, OBJ2);
		}
		return hr;
	}

	@Override
	public int isInstanceOf(int flag, String membername, IntWrapper hint, String classname, Dispatch2 objthis) throws VariantException, TJSException {
		Dispatch2 OBJ1 = ((objthis != null) ? (objthis) : (mDispatch1));
		int hr = mDispatch1.isInstanceOf(flag, membername, hint, classname, OBJ1);
		if(hr == E_MEMBERNOTFOUND && mDispatch1 != mDispatch2) {
			Dispatch2 OBJ2 = ((objthis != null) ? (objthis) : (mDispatch2));
			return mDispatch2.isInstanceOf(flag, membername, hint, classname, OBJ2);
		}
		return hr;
	}

	@Override
	public int isInstanceOfByNum(int flag, int num, String classname, Dispatch2 objthis) throws VariantException, TJSException {
		Dispatch2 OBJ1 = ((objthis != null) ? (objthis) : (mDispatch1));
		int hr = mDispatch1.isInstanceOfByNum(flag, num, classname, OBJ1);
		if(hr == E_MEMBERNOTFOUND && mDispatch1 != mDispatch2) {
			Dispatch2 OBJ2 = ((objthis != null) ? (objthis) : (mDispatch2));
			return mDispatch2.isInstanceOfByNum(flag, num, classname, OBJ2);
		}
		return hr;
	}

	@Override
	public int operation(int flag, String membername, IntWrapper hint, Variant result, Variant param, Dispatch2 objthis) throws VariantException, TJSException {
		Dispatch2 OBJ1 = ((objthis != null) ? (objthis) : (mDispatch1));
		int hr = mDispatch1.operation(flag, membername, hint, result, param, OBJ1);
		if(hr == E_MEMBERNOTFOUND && mDispatch1 != mDispatch2) {
			Dispatch2 OBJ2 = ((objthis != null) ? (objthis) : (mDispatch2));
			return mDispatch2.operation(flag, membername, hint, result, param, OBJ2);
		}
		return hr;
	}

	@Override
	public int operationByNum(int flag, int num, Variant result, Variant param, Dispatch2 objthis) throws VariantException, TJSException {
		Dispatch2 OBJ1 = ((objthis != null) ? (objthis) : (mDispatch1));
		int hr = mDispatch1.operationByNum(flag, num, result, param, OBJ1);
		if(hr == E_MEMBERNOTFOUND && mDispatch1 != mDispatch2) {
			Dispatch2 OBJ2 = ((objthis != null) ? (objthis) : (mDispatch2));
			return mDispatch2.operationByNum(flag, num, result, param, OBJ2);
		}
		return hr;
	}

	@Override
	public int nativeInstanceSupport(int flag, int classid, Holder<NativeInstance> pointer) {
		return E_NOTIMPL;
	}

	@Override
	public int classInstanceInfo(int flag, int num, Variant value) throws VariantException {
		return E_NOTIMPL;
	}

}
