package jp.kirikiri.tjs2;

class TokenPair {
	int token;
	int value;

	TokenPair( int t, int v ) {
		token = t;
		value = v;
	}
}

