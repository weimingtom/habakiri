package jp.kirikiri.tjs2;

public class SimpleGetSetProperty extends Dispatch {

	// 最適化のためにprivateでコピーする
	static private final int
		E_MEMBERNOTFOUND = -1001,
		S_OK = 0;

	private Variant mValue;

	public SimpleGetSetProperty( Variant value) {
		super();
		mValue = value;
	}

	public int propGet( int flag, final String membername, IntWrapper hint, Variant result, Dispatch2 objthis ) {
		if( membername != null ) return E_MEMBERNOTFOUND;
		if( result != null ) result.set( mValue );
		return S_OK;
	}

	public int propSet( int flag, String membername, IntWrapper hint, final Variant param, Dispatch2 objThis ) {
		if( membername != null ) return E_MEMBERNOTFOUND;
		mValue.set( param );
		return S_OK;
	}

	public int propSetByVS( int flag, String membername, final Variant param, Dispatch2 objthis ) {
		if( membername != null ) return E_MEMBERNOTFOUND;
		mValue.set( param );
		return S_OK;
	}
}
