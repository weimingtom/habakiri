package jp.kirikiri.tjs2;

import java.util.HashMap;

class GlobalStringMap {
	private HashMap<String,String> mMap;
	private static final int GLOBAL_STRING_MAP_SIZE = 5000;
	public GlobalStringMap() {
		mMap = new HashMap<String,String>(GLOBAL_STRING_MAP_SIZE);
	}
	public String map( final String str ) {
		String ret = mMap.get( str );
		if( ret != null ) return ret;
		mMap.put( str, str );
		return mMap.get( str );
	}
}
