package jp.kirikiri.tjs2;

public class IntWrapper {
	public int value;
	public IntWrapper( int val ) { value = val; }
	public IntWrapper() { value = 0; }
}

