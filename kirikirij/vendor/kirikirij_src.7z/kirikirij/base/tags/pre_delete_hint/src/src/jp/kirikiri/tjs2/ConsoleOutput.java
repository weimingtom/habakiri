package jp.kirikiri.tjs2;

public interface ConsoleOutput {
	public void exceptionPrint( final String msg );
	public void print( final String msg);
}
