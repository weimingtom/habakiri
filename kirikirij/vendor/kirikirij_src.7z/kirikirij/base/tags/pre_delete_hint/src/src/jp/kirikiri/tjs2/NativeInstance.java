package jp.kirikiri.tjs2;

public interface NativeInstance {

	// TJS constructor
	public int construct( Variant[] param, Dispatch2 tjsObj );

	// called before destruction
	public void invalidate();

	// must destruct itself
	public void destruct();
}
