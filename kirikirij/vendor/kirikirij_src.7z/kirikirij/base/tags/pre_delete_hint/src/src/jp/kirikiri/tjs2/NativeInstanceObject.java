package jp.kirikiri.tjs2;

public class NativeInstanceObject implements NativeInstance {

	private static int S_OK = 0;

	// TJS constructor
	public int construct( Variant[] param, Dispatch2 tjsObj ) {
		return S_OK;
	}

	// called before destruction
	public void invalidate() {}

	// must destruct itself
	public void destruct() {}
}
