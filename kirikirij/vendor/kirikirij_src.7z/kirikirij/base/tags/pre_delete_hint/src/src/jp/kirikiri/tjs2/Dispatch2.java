package jp.kirikiri.tjs2;

public interface Dispatch2 {

	// function invocation
	public int funcCall( int flag, final String memberName, IntWrapper hint, Variant result, Variant[] param, Dispatch2 objThis ) throws VariantException, TJSException;

	// function invocation by index number
	public int funcCallByNum( int flag, int num, Variant result, Variant[] param, Dispatch2 objThis ) throws VariantException, TJSException;

	// property get
	public int propGet( int flag, final String memberName, IntWrapper hint, Variant result, Dispatch2 objThis ) throws VariantException, TJSException;

	// property get by index number
	public int propGetByNum( int flag, int num, Variant result, Dispatch2 objThis ) throws VariantException, TJSException;

	// property set
	public int propSet( int flag, String memberName, IntWrapper hint, final Variant param, Dispatch2 objThis ) throws VariantException, TJSException;

	// property set by index number
	public int propSetByNum( int flag, int num, final Variant param, Dispatch2 objThis ) throws VariantException, TJSException;

	// get member count
	public int getCount( IntWrapper result, final String memberName, IntWrapper hint, Dispatch2 objThis ) throws VariantException, TJSException;

	// get member count by index number ( result is Integer )
	public int getCountByNum( IntWrapper result, int num, Dispatch2 objThis ) throws VariantException, TJSException;

	// property for internal use
	public int propSetByVS( int flag, String membername, final Variant param, Dispatch2 objthis ) throws VariantException, TJSException;

	// enumerate members
	public int enumMembers( int flag, VariantClosure callback, Dispatch2 objThis ) throws VariantException, TJSException;

	// delete member
	public int deleteMember( int flag, String memberName, IntWrapper hint, Dispatch2 objThis ) throws VariantException, TJSException;

	// delete member by index number
	public int deleteMemberByNum( int flag, int num, Dispatch2 objThis ) throws VariantException, TJSException;

	// invalidation
	public int invalidate( int flag, String memberName, IntWrapper hint, Dispatch2 objThis ) throws VariantException, TJSException;

	// invalidation by index number
	public int invalidateByNum( int flag, int num, Dispatch2 objThis ) throws VariantException, TJSException;

	// get validation, returns true or false
	public int isValid( int flag, String memberName, IntWrapper hint, Dispatch2 objThis ) throws VariantException, TJSException;

	// get validation by index number, returns true or false
	public int isValidByNum( int flag, int num, Dispatch2 objThis ) throws VariantException, TJSException;

	// create new object
	public int createNew( int flag, String memberName, IntWrapper hint, Holder<Dispatch2> result, Variant[] param, Dispatch2 objThis ) throws VariantException, TJSException;

	// create new object by index number
	public int createNewByNum( int flag, int num, Holder<Dispatch2> result, Variant[] param, Dispatch2 objThis ) throws VariantException, TJSException;

	// reserved1 not use

	// class instance matching returns false or true
	public int isInstanceOf( int flag, String memberName, IntWrapper hint, String className, Dispatch2 objThis ) throws VariantException, TJSException;

	// class instance matching by index number
	public int isInstanceOfByNum( int flag, int num, String className, Dispatch2 objThis ) throws VariantException, TJSException;

	// operation with member
	public int operation( int flag, String memberName, IntWrapper hint, Variant result, final Variant param, Dispatch2 objThis ) throws VariantException, TJSException;

	// operation with member by index number
	public int operationByNum( int flag, int num, Variant result, final Variant param, Dispatch2 objThis ) throws VariantException, TJSException;

	// support for native instance
	public int nativeInstanceSupport( int flag, int classid, Holder<NativeInstance> pointer );

	// support for class instance infomation
	public int classInstanceInfo( int flag, int num, Variant value ) throws VariantException;

	// reserved2
	// reserved3
}
