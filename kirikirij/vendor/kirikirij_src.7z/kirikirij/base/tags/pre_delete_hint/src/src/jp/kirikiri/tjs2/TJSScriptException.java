package jp.kirikiri.tjs2;

public class TJSScriptException extends TJSScriptError {

	/**
	 *
	 */
	private static final long serialVersionUID = 5461681283822047431L;

	private Variant mValue;
	public TJSScriptException(String Msg, ScriptBlock block, int pos, Variant val ) {
		super(Msg, block, pos);
		mValue = val;
	}
	public TJSScriptException( final TJSScriptException ref) {
		super(ref);
		mValue = ref.mValue;
	}
	public Variant getValue() { return mValue; }
}
