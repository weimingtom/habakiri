package jp.kirikiri.tjs2;

public class Holder<T> {
	public T mValue;
	public Holder( T v ) { this.mValue = v; }
	public T get() { return mValue; }
	public void set( T v ) { mValue = v; }
}

