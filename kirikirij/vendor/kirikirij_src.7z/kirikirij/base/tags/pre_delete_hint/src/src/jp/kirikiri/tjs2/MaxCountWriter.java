package jp.kirikiri.tjs2;

interface MaxCountWriter {
	public void setMaxCount( int count );
}
