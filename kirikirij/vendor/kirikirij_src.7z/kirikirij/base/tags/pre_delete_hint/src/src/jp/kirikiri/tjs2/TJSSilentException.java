package jp.kirikiri.tjs2;

public class TJSSilentException extends Exception {

	/**
	 *
	 */
	private static final long serialVersionUID = 51839351639123183L;

	public TJSSilentException() {}
	public TJSSilentException( String msg ) {
		super( msg );
	}
}
