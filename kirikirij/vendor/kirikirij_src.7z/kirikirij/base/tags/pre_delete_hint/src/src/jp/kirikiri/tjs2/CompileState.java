package jp.kirikiri.tjs2;

public class CompileState {
	public static boolean mEnableDicFuncQuickHack = true;
}
