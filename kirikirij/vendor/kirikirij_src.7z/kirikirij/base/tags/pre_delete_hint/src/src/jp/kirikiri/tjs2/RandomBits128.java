// retrives 128-bits (16bytes) random bits for random seed.
// this can be override application-specified routine, otherwise
// TJS2 uses current time as a random seed.
package jp.kirikiri.tjs2;

import java.nio.ByteBuffer;

public interface RandomBits128 {
	public void getRandomBits128( ByteBuffer buf, int offset );
}
