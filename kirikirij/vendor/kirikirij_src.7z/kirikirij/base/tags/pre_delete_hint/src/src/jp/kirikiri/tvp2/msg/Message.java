/**
 * Message Strings ( these should be localized )
 */
package jp.kirikiri.tvp2.msg;

public class Message {
	// Japanese localized messages
	static public final String ScriptExceptionRaised = "スクリプトで例外が発生しました";
	static public final String HardwareExceptionRaised = "ハードウェア例外が発生しました";
	static public final String MainCDPName = "スクリプトエディタ (メイン)";
	static public final String ExceptionCDPName = "スクリプトエディタ (例外通知)";
	static public final String CannnotLocateUIDLLForFolderSelection = "フォルダ/アーカイブの選択画面を表示しようとしましたが krdevui.dll が見つからないので表示できません.\n実行するフォルダ/アーカイブはコマンドラインの引数として指定してください";
	static public final String InvalidUIDLL = "krdevui.dll が異常か、バージョンが一致しません";
	static public final String InvalidBPP = "無効な色深度です";
	static public final String CannotLoadPlugin = "プラグイン %1 を読み込めません";
	static public final String NotValidPlugin = "%1 は有効なプラグインではありません";
	static public final String PluginUninitFailed = "プラグインの解放に失敗しました";
	static public final String CannnotLinkPluginWhilePluginLinking = "プラグインの接続中に他のプラグインを接続することはできまません";
	static public final String NotSusiePlugin = "異常な Susie プラグインです";
	static public final String SusiePluginError = "Susie プラグインでエラーが発生しました/エラーコード %1";
	static public final String CannotReleasePlugin = "指定されたプラグインは使用中のため解放できません";
	static public final String NotLoadedPlugin = "%1 は読み込まれていません";
	static public final String CannotAllocateBitmapBits = "ビットマップ用メモリを確保できません/%1(size=%2)";
	static public final String ScanLineRangeOver = "スキャンライン %1 は範囲(0～%2)を超えています";
	static public final String PluginError = "プラグインでエラーが発生しました/%1";
	static public final String InvalidCDDADrive = "指定されたドライブでは CD-DA を再生できません";
	static public final String CDDADriveNotFound = "CD-DA を再生できるドライブが見つかりません";
	static public final String MCIError = "MCI でエラーが発生しました : %1";
	static public final String InvalidSMF = "有効な SMF ファイルではありません : %1";
	static public final String MalformedMIDIMessage = "指定されたメッセージは MIDI メッセージとして有効な形式ではありません";
	static public final String CannotInitDirectSound = "DirectSound を初期化できません : %1";
	static public final String CannotCreateDSSecondaryBuffer = "DirectSound セカンダリバッファを作成できません : %1/%2";
	static public final String InvalidLoopInformation = "ループ情報 %1 は異常です";
	static public final String NotChildMenuItem = "指定されたメニュー項目はこのメニュー項目の子ではありません";
	static public final String CannotInitDirectDraw = "DirectDraw を初期化できません : %1";
	static public final String CannotFindDisplayMode = "適合する画面モードが見つかりません : %1";
	static public final String CannotSwitchToFullScreen = "フルスクリーンに切り替えられません : %1";
	static public final String InvalidPropertyInFullScreen = "フルスクリーン中では操作できないプロパティを設定しようとしました";
	static public final String InvalidMethodInFullScreen = "フルスクリーン中では操作できないメソッドを呼び出そうとしました";
	static public final String CannotLoadCursor = "マウスカーソル %1 の読み込みに失敗しました";
	static public final String CannotLoadKrMovieDLL = "ビデオ/Shockwave Flash を再生するためには krmovie.dll / krflash.dll が必要ですが 読み込むことができません";
	static public final String InvalidKrMovieDLL = "krmovie.dll/krflash.dll が異常か 対応できないバージョンです";
	static public final String ErrorInKrMovieDLL = "krmovie.dll/krflash.dll 内でエラーが発生しました/%1";
	static public final String WindowAlreadyMissing = "ウィンドウはすでに存在していません";
	static public final String PrerenderedFontMappingFailed = "レンダリング済みフォントのマッピングに失敗しました : %1";
	static public final String ConfigFailOriginalFileCannotBeRewritten = "%1 に書き込みできません。ソフトウェアが実行中のままになっていないか、あるいは書き込み権限があるかどうかを確認してください";
	static public final String ConfigFailTempExeNotErased = "%1 の終了を確認できないため、これを削除できませんでした(このファイルは削除して結構です)";
	static public final String ExecutionFail = "%1 を実行できません";
	static public final String PluginUnboundFunctionError = "プラグインから関数 %1 を要求されましたが、その関数は本体内に存在しません。プラグインと本体のバージョンが正しく対応しているか確認してください";
	static public final String ExceptionHadBeenOccured = " = (例外発生)";
	static public final String ConsoleResult = "コンソール : ";
};
