package jp.kirikiri.tjs2;

public class TJSException extends Exception {

	/**
	 *
	 */
	private static final long serialVersionUID = 1942890050230766470L;
	public TJSException() {}
	public TJSException( String msg ) {
		super( msg );
	}
}

