package jp.kirikiri.tjs2;

class ContextType {
	public static final int
		TOP_LEVEL = 0,
		FUNCTION = 1,
		EXPR_FUNCTION = 2,
		PROPERTY = 3,
		PROPERTY_SETTER = 4,
		PROPERTY_GETTER = 5,
		CLASS = 6,
		SUPER_CLASS_GETTER = 7;
}
