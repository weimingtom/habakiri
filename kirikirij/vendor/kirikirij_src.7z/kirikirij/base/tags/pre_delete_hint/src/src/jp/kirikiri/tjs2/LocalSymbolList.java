package jp.kirikiri.tjs2;

import java.util.Vector;

class LocalSymbolList {
	private Vector<String> mList;
	private int mLocalCountStart;
	//private int mStartWrite;
	//private int mCountWrite;

	public LocalSymbolList( int localCount ) {
		mLocalCountStart = localCount;
		//mStartWrite = mCountWrite = 0;
		mList = new Vector<String>();
	}
	public void add( final String name ) {
		if( find(name) == -1 ) {
			String str = new String(name);
			final int size = mList.size();
			for( int i = 0; i < size; i++ ) {
				String s = mList.get(i);
				if( s == null ) {
					mList.set( i, str );
				}
			}
			mList.add(str);
		}
	}
	public int find( final String name ) {
		final int size = mList.size();
		for( int i = 0; i < size; i++ ) {
			String str = mList.get(i);
			if( str != null && name.equals(str) ) {
				return i;
			}
		}
		return -1;
	}
	public void remove( final String name ) {
		int index = find(name);
		if( index != -1 ) {
			mList.set( index, null );
		}
	}

	public int getCount() { return mList.size(); }
	public int getLocalCountStart() { return mLocalCountStart; }
}

