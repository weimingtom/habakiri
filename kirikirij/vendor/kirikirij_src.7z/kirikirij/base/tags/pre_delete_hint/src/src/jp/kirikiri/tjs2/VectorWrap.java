package jp.kirikiri.tjs2;

// vector を ArrayList で置き換えるためのクラス

import java.util.ArrayList;
import java.util.Collection;

public class VectorWrap<E> extends ArrayList<E> {

	/**
	 *
	 */
	private static final long serialVersionUID = -8162877809635079713L;

	public VectorWrap() {
		super();
	}
	public VectorWrap(Collection<? extends E> c) {
		super(c);
	}
	public VectorWrap(int initialCapacity) {
		super(initialCapacity);
	}

	public E lastElement() { return get( size() -1 ); }
	public E back() { return get( size() -1 ); }
	public void pop_back() { remove( size()-1 ); }
}
